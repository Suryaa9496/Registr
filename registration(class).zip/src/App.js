import React from 'react';
import RegistrationPage from './RegistrationPage';

function App() {
  return (
    <div>
      <RegistrationPage />
    </div>
  );
}

export default App;
