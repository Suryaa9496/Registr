import React, { useState } from 'react';
import './registration.css';

function RegistrationPage() {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    companyName: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="container">
      <h2>Registration Page</h2>
      <form id="registrationForm">
        <div>
          <label htmlFor="name">Name:</label>
          <input 
            type="text" 
            id="name" 
            name="name" 
            value={formData.name} 
            onChange={handleChange} 
            required 
          />
          {formData.name && <p>{formData.name}</p>}
        </div>
        <div>
          <label htmlFor="age">Age:</label>
          <input 
            type="number" 
            id="age" 
            name="age" 
            value={formData.age} 
            onChange={handleChange} 
            required 
          />
          {formData.age && <p>{formData.age}</p>}
        </div>
        <div>
          <label htmlFor="companyName">Company Name:</label>
          <input 
            type="text" 
            id="companyName" 
            name="companyName" 
            value={formData.companyName} 
            onChange={handleChange} 
            required 
          />
          {formData.companyName && <p>{formData.companyName}</p>}
        </div>
        <button className="btn" type="submit">Publish</button>
      </form>
    </div>
  );
}

export default RegistrationPage;
